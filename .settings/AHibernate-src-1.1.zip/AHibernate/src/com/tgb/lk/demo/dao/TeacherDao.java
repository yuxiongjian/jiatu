package com.tgb.lk.demo.dao;

import com.tgb.lk.ahibernate.dao.BaseDao;
import com.tgb.lk.demo.model.Teacher;

public interface TeacherDao extends BaseDao<Teacher> {

}
